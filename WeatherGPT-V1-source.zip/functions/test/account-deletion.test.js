const test = require("node:test");
const assert = require("node:assert/strict");
const { createDeleteOwnAccountData, DELETE_COOLDOWN_MS } = require("../account-deletion");

class HttpsError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

function createDb() {
  const documents = new Map();
  const deletedPaths = [];
  const db = {
    doc(path) {
      return { path };
    },
    async runTransaction(operation) {
      await operation({
        async get(reference) {
          const data = documents.get(reference.path);
          return { data: () => data };
        },
        set(reference, data) {
          documents.set(reference.path, data);
        }
      });
    },
    async recursiveDelete(reference) {
      deletedPaths.push(reference.path);
    },
    documents,
    deletedPaths
  };
  return db;
}

function request(overrides = {}) {
  return {
    auth: { uid: "user-1", token: { email_verified: true } },
    app: { appId: "test-app" },
    ...overrides
  };
}

test("requires verified authentication and App Check before accessing Firestore", async () => {
  const db = createDb();
  const handler = createDeleteOwnAccountData({
    db, HttpsError, Timestamp: { fromMillis: (value) => value }
  });
  await assert.rejects(handler(request({
    auth: { uid: "user-1", token: { email_verified: false } }
  })), {
    code: "unauthenticated"
  });
  await assert.rejects(handler(request({ app: undefined })), { code: "failed-precondition" });
  assert.deepEqual(db.deletedPaths, []);
  assert.equal(db.documents.size, 0);
});

test("recursively deletes only the authenticated user's profile tree and rate limits retries", async () => {
  const db = createDb();
  let currentTime = 1_800_000_000_000;
  const handler = createDeleteOwnAccountData({
    db,
    HttpsError,
    Timestamp: { fromMillis: (value) => ({ toMillis: () => value }) },
    now: () => currentTime
  });
  assert.deepEqual(await handler(request()), { deleted: true });
  assert.deepEqual(db.deletedPaths, ["users/user-1"]);
  await assert.rejects(handler(request()), { code: "resource-exhausted" });
  currentTime += DELETE_COOLDOWN_MS;
  assert.deepEqual(await handler(request()), { deleted: true });
  assert.deepEqual(db.deletedPaths, ["users/user-1", "users/user-1"]);
});

test("shapes recursive deletion failures without exposing implementation details", async () => {
  const db = createDb();
  db.recursiveDelete = async () => {
    throw new Error("internal firestore details");
  };
  const handler = createDeleteOwnAccountData({
    db,
    HttpsError,
    Timestamp: { fromMillis: (value) => value }
  });
  await assert.rejects(handler(request()), (error) =>
    error.code === "unavailable" && !error.message.includes("internal firestore details"));
});

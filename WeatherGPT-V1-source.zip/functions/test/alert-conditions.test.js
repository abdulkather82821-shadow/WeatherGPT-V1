const test = require("node:test");
const assert = require("node:assert/strict");
const { classifyForecastAlerts } = require("../alert-conditions");

test("scheduled worker loads with the configured Firebase SDKs", () => {
  const worker = require("../index");
  assert.equal(typeof worker.sendForecastEmailAlerts, "function");
});

function forecast(overrides = {}) {
  return {
    current: { weather_code: 1, wind_speed_10m: 10 },
    daily: {
      precipitation_probability_max: [20],
      precipitation_sum: [0],
      temperature_2m_max: [28],
      temperature_2m_min: [17]
    },
    hourly: { wind_speed_10m: Array(24).fill(10) },
    ...overrides
  };
}

test("normal forecasts do not generate disaster emails", () => {
  assert.deepEqual(classifyForecastAlerts(forecast()), {});
});

test("qualifying rain, storm, wind, heat and cold signals are classified independently", () => {
  const data = forecast({
    current: { weather_code: 95, wind_speed_10m: 52 },
    daily: {
      precipitation_probability_max: [70],
      precipitation_sum: [12],
      temperature_2m_max: [41],
      temperature_2m_min: [4]
    },
    hourly: { wind_speed_10m: [55] }
  });
  assert.deepEqual(Object.keys(classifyForecastAlerts(data)).sort(), ["cold", "heat", "rain", "storm", "wind"]);
});

test("rain alerts require meaningful probability and rainfall together", () => {
  const lowAmount = forecast({ daily: { precipitation_probability_max: [90], precipitation_sum: [0], temperature_2m_max: [28], temperature_2m_min: [17] } });
  const lowProbability = forecast({ daily: { precipitation_probability_max: [20], precipitation_sum: [12], temperature_2m_max: [28], temperature_2m_min: [17] } });
  assert.equal(classifyForecastAlerts(lowAmount).rain, undefined);
  assert.equal(classifyForecastAlerts(lowProbability).rain, undefined);
});

test("missing forecast data fails explicitly", () => {
  assert.throws(() => classifyForecastAlerts({ current: null }), /missing current or daily/);
});

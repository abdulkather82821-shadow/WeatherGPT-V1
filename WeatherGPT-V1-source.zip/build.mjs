import { cpSync, mkdirSync, rmSync, copyFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const output = resolve(root, "www");
const shellFiles = ["index.html", "app.js", "styles.css", "site.webmanifest", "icon.svg", "sw.js"];

rmSync(output, { recursive: true, force: true });
mkdirSync(output, { recursive: true });

for (const file of shellFiles) copyFileSync(resolve(root, file), resolve(output, file));

const leafletSource = resolve(root, "node_modules", "leaflet", "dist");
const leafletDestination = resolve(output, "node_modules", "leaflet", "dist");
mkdirSync(dirname(leafletDestination), { recursive: true });
cpSync(leafletSource, leafletDestination, { recursive: true });

console.log("Built the WeatherGPT web app and Android WebView assets in www/.");

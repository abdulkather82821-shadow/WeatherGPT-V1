import { Capacitor } from "@capacitor/core";
import { FirebaseAppCheck } from "@capacitor-firebase/app-check";
import { FirebaseAuthentication } from "@capacitor-firebase/authentication";
import { getApp, getApps, initializeApp } from "firebase/app";
import { CustomProvider, ReCaptchaV3Provider, initializeAppCheck } from "firebase/app-check";
import {
  GoogleAuthProvider,
  getAuth,
  indexedDBLocalPersistence,
  initializeAuth,
  onAuthStateChanged,
  signInWithCredential,
  signInWithPopup,
  signOut
} from "firebase/auth";
import { doc, getDoc, getFirestore, serverTimestamp, setDoc } from "firebase/firestore";

const requiredKeys = ["apiKey", "authDomain", "projectId", "appId"];
const firebaseConfig = window.WEATHERGPT_FIREBASE_CONFIG;
const isConfigured = requiredKeys.every((key) => {
  const value = firebaseConfig?.[key];
  return typeof value === "string" && value.length > 0 && !value.startsWith("REPLACE_");
});
let auth;
let database;
let unsubscribeAuth;
let userCallback;

function updateAuthUser(user) {
  userCallback?.(user);
}

async function synchronizeNativeUser() {
  const result = await FirebaseAuthentication.getCurrentUser();
  if (!result.user) {
    if (auth.currentUser) await signOut(auth);
    return;
  }
  if (auth.currentUser?.uid === result.user.uid) return;
  const tokenResult = await FirebaseAuthentication.getIdToken();
  if (!tokenResult.token) throw new Error("Google sign-in did not return a Firebase identity token.");
  const credential = GoogleAuthProvider.credential(tokenResult.token);
  await signInWithCredential(auth, credential);
}

async function initialize(onUser) {
  userCallback = onUser;
  if (!isConfigured) {
    updateAuthUser(null);
    return false;
  }

  const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
  if (Capacitor.isNativePlatform()) {
    await FirebaseAppCheck.initialize({ isTokenAutoRefreshEnabled: true });
    initializeAppCheck(app, {
      provider: new CustomProvider({ getToken: () => FirebaseAppCheck.getToken() }),
      isTokenAutoRefreshEnabled: true
    });
    try {
      auth = initializeAuth(app, { persistence: indexedDBLocalPersistence });
    } catch (error) {
      if (error.code !== "auth/already-initialized") throw error;
      auth = getAuth(app);
    }
  } else {
    if (!firebaseConfig.recaptchaV3SiteKey || firebaseConfig.recaptchaV3SiteKey.startsWith("REPLACE_")) {
      throw new Error("A reCAPTCHA v3 site key is required to use protected Firebase email settings on the web.");
    }
    initializeAppCheck(app, {
      provider: new ReCaptchaV3Provider(firebaseConfig.recaptchaV3SiteKey),
      isTokenAutoRefreshEnabled: true
    });
    auth = getAuth(app);
  }
  database = getFirestore(app);
  unsubscribeAuth?.();
  unsubscribeAuth = onAuthStateChanged(auth, updateAuthUser);
  if (Capacitor.isNativePlatform()) await synchronizeNativeUser();
  return true;
}

async function signInWithGoogle() {
  if (!auth) throw new Error("Google sign-in is not configured. Add your Firebase app configuration and sync the Android project.");
  if (Capacitor.isNativePlatform()) {
    const result = await FirebaseAuthentication.signInWithGoogle();
    const idToken = result.credential?.idToken;
    if (!idToken) throw new Error("Google sign-in did not return an identity token. Check your Firebase Android SHA-1 setup.");
    await signInWithCredential(auth, GoogleAuthProvider.credential(idToken));
    return;
  }
  await signInWithPopup(auth, new GoogleAuthProvider());
}

async function signOutUser() {
  if (!auth) return;
  if (Capacitor.isNativePlatform()) await FirebaseAuthentication.signOut();
  await signOut(auth);
}

function getSignedInUser() {
  return auth?.currentUser || null;
}

async function loadEmailPreferences() {
  const user = getSignedInUser();
  if (!user || !database) throw new Error("Sign in with Google before loading email preferences.");
  const snapshot = await getDoc(doc(database, "users", user.uid));
  return snapshot.exists() ? snapshot.data().emailAlerts || null : null;
}

async function saveEmailPreferences(preferences) {
  const user = getSignedInUser();
  if (!user || !database) throw new Error("Sign in with Google before saving email preferences.");
  if (!user.emailVerified || !user.email) throw new Error("A verified Google email address is required for email alerts.");
  const latitude = Number(preferences.location?.latitude);
  const longitude = Number(preferences.location?.longitude);
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90 || !Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    throw new Error("A valid forecast location is required before enabling email alerts.");
  }
  const categories = ["rain", "storm", "wind", "heat", "cold"].reduce((result, category) => {
    result[category] = preferences.categories?.[category] === true;
    return result;
  }, {});
  const enabled = preferences.consent === true && Object.values(categories).some(Boolean);
  await setDoc(doc(database, "users", user.uid), {
    emailAlerts: {
      enabled,
      categories,
      location: {
        name: String(preferences.location.name || "Selected location").slice(0, 100),
        latitude,
        longitude,
        timezone: String(preferences.location.timezone || "auto").slice(0, 80)
      }
    },
    updatedAt: serverTimestamp()
  }, { merge: true });
  return { enabled, email: user.email };
}

window.WeatherGPTFirebase = {
  configured: isConfigured,
  initialize,
  signInWithGoogle,
  signOut: signOutUser,
  getSignedInUser,
  loadEmailPreferences,
  saveEmailPreferences
};

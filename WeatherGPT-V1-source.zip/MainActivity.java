package com.weathergpt.mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
